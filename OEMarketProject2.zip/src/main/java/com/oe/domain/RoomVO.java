package com.oe.domain;

import lombok.Data;

@Data
public class RoomVO {
	int roomNumber;
	String roomName;
	
}
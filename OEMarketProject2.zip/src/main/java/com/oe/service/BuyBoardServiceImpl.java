package com.oe.service;

public class BuyBoardServiceImpl {

}

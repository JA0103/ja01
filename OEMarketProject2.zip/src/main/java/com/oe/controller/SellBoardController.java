package com.oe.controller;


/*
SEL_NUM      NOT NULL NUMBER        
SEL_NICKNAME          VARCHAR2(30)  
SEL_TITLE             VARCHAR2(100) 
SEL_PRICE             NUMBER        
SEL_BUYER             VARCHAR2(30)  
SEL_SELLDATE          DATE    
 */


public class SellBoardController {

}

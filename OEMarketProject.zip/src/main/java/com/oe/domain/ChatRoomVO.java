package com.oe.domain;

import lombok.Data;

@Data
public class ChatRoomVO {
	private int cr_roomNumber;
	private String cr_roomName;
	
}
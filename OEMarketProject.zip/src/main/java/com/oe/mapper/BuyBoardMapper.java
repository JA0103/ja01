package com.oe.mapper;

public interface BuyBoardMapper {

}
